<?php
$mail_id1 = "sandeepkumbaruk100@gmail.com";
$mail_name1 = "Sandeep";
$mail_password1 = "pnuz vghq iroc qswg";

$mail_id2 = "";
$mail_name2 = "";
$mail_password2 = "";

session_start();

// function to unssest all sessions
function unset_all()
{
    unset($_SESSION['subject']);
    unset($_SESSION['mail_no']);
    unset($_SESSION['receiver_mail']);
    unset($_SESSION['host']);
    unset($_SESSION['is_captcha']);
}

// function to collect and sanitize inputs
function clean($str)
{
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

//Redirect to page with specific alert
function alert_header($alert_msg, $location)
{
    echo "<script>alert('$alert_msg');window.location='$location';</script>";
    exit();
}

//Redirect to page with no alert
function no_alert_header($location)
{
    echo "<script>window.location='$location';</script>";
    exit();
}

$subject = isset($_POST['subject']) ? clean($_POST['subject']) : '';
if ($subject == '') {
    $subject = $_SESSION['subject'];
}

if ($subject == '') {
    alert_header("Subject Missing", 'form');
    unset_all();
    exit;
}

$receiver_mail = isset($_POST['receiver_mail']) ? clean($_POST['receiver_mail']) : '';
if ($receiver_mail == '') {
    $receiver_mail = $_SESSION['receiver_mail'];
}

if ($receiver_mail == '') {
    alert_header("Receiver Mail Missing", 'form');
    unset_all();
    exit;
}

$host = $_SESSION['host'];
if (
    $host != "gmail" &&
    $host != "email" &&
    $host != "yahoo" &&
    $host != "outlook" &&
    $host != "hotmail" &&
    $host != "godaddy" &&
    $host != "hostinger" &&
    $host != "zoho" &&
    $host != "namecheap" &&
    $host != "bluehost" &&
    $host != "ionos" &&
    $host != "1and1" &&
    $host != "protonmail"
) {
    alert_header("Host Undefined", 'form');
    unset_all();
    exit;
}

$mail_no = $_SESSION['mail_no'];
$mail_id = "mail_id" . $mail_no;
$mail_name = "mail_name" . $mail_no;;
$mail_password = "mail_password" . $mail_no;
if ($$mail_id == "") {
    alert_header("Mail Number not defined or Mail Id is not defined in form_handler", 'form');
    unset_all();
    exit;
}

$is_captcha = $_SESSION['is_captcha'];

unset_all();

$allowed_tags = '<b><br><hr><i><u><a>';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Bot protection: honeypot field (should remain empty)
if (!empty($_POST['website'])) {
    no_alert_header("form");
    exit;
}

$sender_mail = isset($_POST['sender']) ? clean($_POST['sender_mail']) : '';
$sender_name = isset($_POST['sender']) ? clean($_POST['sender_name']) : '';
$heading     = isset($_POST['heading']) ? clean($_POST['heading']) : '';
$top_msg  = isset($_POST['top_msg']) && is_array($_POST['top_msg']) ? $_POST['top_msg'] : [];
$bottom_msg = isset($_POST['bottom_msg']) && is_array($_POST['bottom_msg']) ? $_POST['bottom_msg'] : [];
$string_names  = isset($_POST['string_name']) ? $_POST['string_name'] : [];
$string_values = isset($_POST['string_value']) ? $_POST['string_value'] : [];
$regards     = isset($_POST['regards']) ? strip_tags($_POST['regards'], $allowed_tags) : '';
$user_alert_message = isset($_POST['user_alert_message']) ? strip_tags($_POST['user_alert_message'], $allowed_tags) : '';
$success_header = isset($_POST['success_header']) ? strip_tags($_POST['success_header'], $allowed_tags) : '';


if ($is_captcha == 1) {
    $secretKey = '6LcfChErAAAAAKJBM2ApQF4ROjPkAG4AQzDmbykJ';
    $response = $_POST['g-recaptcha-response'] ?? '';

    $verify = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret={$secretKey}&response={$response}");
    $captcha_success = json_decode($verify);

    if (!$captcha_success->success) {
        exit('CAPTCHA validation failed. Please try again.');
    }
}

//Initialize mailer
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = "smtp." . $host . ".com";
    $mail->SMTPAuth   = true;
    $mail->Username   = $$mail_id;
    $mail->Password   = $$mail_password;
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom($$mail_id, $$mail_name);
    $mail->addAddress($receiver_mail);
    $mail->isHTML(true);
    $mail->Subject = $subject;

    //Compose body
    $body = "<html><body style='font-family: Arial, sans-serif;'>";
    if ($heading)     $body .= "<h2 style='font-weight: bold;'>$heading</h2><br><br>";
    foreach ($top_msg as $msg) {
        $body .= strip_tags($msg, $allowed_tags) . '<br><br>';
    }

    if (
        !empty($string_names) && !empty($string_values) &&
        is_array($string_names) && is_array($string_values)
    ) {

        $body .= "<table cellspacing='0' cellpadding='6' border='1' style='border-collapse: collapse;'>";

        for ($i = 0; $i < count($string_names); $i++) {
            $name = strip_tags($string_names[$i], $allowed_tags);
            $value = strip_tags($string_values[$i], $allowed_tags);

            // Make smart links for phone and email
            if (preg_match('/phone|mobile/i', $name)) {
                $href = 'tel: +91' . preg_replace('/[^0-9]/', '', $value);
                $value = "<a href='$href'>$value</a>";
            } elseif (preg_match('/email/i', $name) && filter_var($value, FILTER_VALIDATE_EMAIL)) {
                $value = "<a href='mailto:$value'>$value</a>";
            }

            if ($name || $value) {
                $body .= "<tr><td><strong>$name</strong></td><td>$value</td></tr>";
            }
        }

        $body .= "</table><br>";
    }


    $body .= "<br>";

    foreach ($bottom_msg as $msg) {
        $body .= strip_tags($msg, $allowed_tags) . '<br><br>';
    }
    if ($regards)     $body .= "<p>Regards,<br>$regards</p>";
    $body .= "</body></html>";

    $mail->Body = $body;

    //File type whitelist
    $allowed_types = [
        'image/jpeg',
        'image/png',
        'image/gif',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain',
        'text/csv',
        'application/csv',
        'application/vnd.oasis.opendocument.spreadsheet',

        //Archive formats
        'application/zip',
        'application/x-rar-compressed',

        //Video formats
        'video/mp4',
        'video/x-msvideo', // .avi
        'video/x-matroska', // .mkv
        'video/quicktime', // .mov
        'video/webm'
    ];
    $max_file_size = 5 * 1024 * 1024; // 5MB

    $uploadFields = ['img', 'pdf', 'docs'];
    foreach ($uploadFields as $field) {
        if (!empty($_FILES[$field]['name'][0])) {
            for ($i = 0; $i < count($_FILES[$field]['name']); $i++) {
                $tmp  = $_FILES[$field]['tmp_name'][$i];
                $name = basename($_FILES[$field]['name'][$i]);
                $type = $_FILES[$field]['type'][$i];
                $size = $_FILES[$field]['size'][$i];
                $err  = $_FILES[$field]['error'][$i];

                if ($err === UPLOAD_ERR_OK && in_array($type, $allowed_types) && $size <= $max_file_size) {
                    $mail->addAttachment($tmp, $name);
                }
            }
        }
    }

    //Attach files from DB path via input field
    if (isset($_POST['db_file']) && is_array($_POST['db_file'])) {
        foreach ($_POST['db_file'] as $db_path) {
            $clean_path = trim($db_path);
            $ext = strtolower(pathinfo($clean_path, PATHINFO_EXTENSION));
            $mime = mime_content_type($clean_path);

            if (!empty($clean_path) && file_exists($clean_path) && in_array($mime, $allowed_types)) {
                $mail->addAttachment($clean_path);
            }
        }
    }

    $mail->send();
    if($user_alert_message != '' and $success_header != ''){
        alert_header($user_alert_message, $success_header);
    }elseif($user_alert_message == '' and $success_header != ''){
        no_alert_header($success_header);
    }elseif($user_alert_message != '' and $success_header == ''){
        alert_header($user_alert_message, "/index");
    }else{
        no_alert_header("/index");
    }
} catch (Exception $e) {
    echo "Mailer Error: {$mail->ErrorInfo}";
}
?>