<!DOCTYPE html>
<html>

<head>
  <title>NifTyccon Form Templete for Mail Form</title>
</head>
<h1>This file is just a demo for user to create a forms</h1>
<?php
session_start();
// include('db/dbconn.php');
// include('common/php/niftycoon_functions.php');

$_SESSION['mail_no'] = "1"; // mail's number defined in form_handler
$_SESSION['receiver_mail'] = "www.sandeepkumbaruk100@gmail.com"; // If reciver mail is fetched from user leave this blank
$_SESSION['subject'] = "";  // If subject is fetched from user leave this blank

/*
  Allowed Host Identifiers (Use these values in $host):

  - Gmail        : "gmail"
  - Outlook      : "outlook"
  - Hotmail      : "hotmail"
  - Yahoo        : "yahoo"
  - GoDaddy      : "godaddy"
  - Hostinger    : "hostinger"
  - Zoho         : "zoho"
  - Namecheap    : "namecheap"
  - Bluehost     : "bluehost"
  - IONOS (1&1)  : "ionos" or "1and1"
  - ProtonMail   : "protonmail"
  - Custom Email : "email"   // For any generic/self-hosted SMTP setup
*/
$_SESSION['host'] = "gmail";
$_SESSION['is_captcha'] = "1"; // 1 if enebled for this form, or else 0
?>

<body>

  <h2>Contact Form</h2>
  <?php // action="" should always point to the niftycoon_mailer/form-handler.php 
  ?>
  <form action="form-handler.php" method="POST" enctype="multipart/form-data">

    <?php //This is mandatory to add below input name="website" at the top,  this input is to detect bot as bot fill all the fields even it is not visible 
    ?>
    <input type="text" name="website" placeholder="Mandatory input tag" value="" style="display:none">
    <!-- <input type="hidden" name="receiver_mail" value="www.sandeepkumbaruk100@gmail.com"> -->
    <input type="hidden" name="subject" value="User Subject">
    <input type="hidden" name="heading" value="Bold Heading one line">
    <input type="hidden" name="top_msg[]" value="Hi NifTycoon,">
    <input type="hidden" name="top_msg[]" value="<br><hr>"> <!-- <br><br> to add extra break bellow. <hr> to add line below-->
    <input type="hidden" name="top_msg[]" value="<i>Top Messages can be added and/or taken from user (i tag italic)</i>">
    <input type="hidden" name="top_msg[]" value="<b>Top Messages can be added and/or taken from user (b tag bold)</b>"> <!-- can use <b> tag to bold text -->
    <input type="text" name="top_msg[]" value="" required>

    <!-- Dynamic name-value pairs this will be in table form Table will not accept ant html Tags!! -->
    <input type="hidden" name="string_name[]" value="Name">
    <input type="hidden" name="string_value[]" value="Sandeep">

    <!-- If string_name[] includes phone or mobile for string_value[] automatically add <a href 'tel:'> link for provided phone number-->
    <input type="hidden" name="string_name[]" value="Phone No.">
    <input type="hidden" name="string_value[]" value="7760735129">

    <input type="hidden" name="string_name[]" value="Product">
    <input type="hidden" name="string_value[]" value="Fire Door">

    <!-- If string_name[] includes mail for string_value[] automatically add <a href 'mail:'> link for provided mail id-->
    <input type="hidden" name="string_name[]" value="Mail Id">
    <input type="hidden" name="string_value[]" value="sandeepkumbaruk100@gmail.com">

    <!-- Optional bottom message -->
    <input type="hidden" name="bottom_msg[]" value="Bottom message same as Top message">
    <input type="hidden" name="bottom_msg[]" value="Thank you for the enquiry.">
    <input type="hidden" name="bottom_msg[]" value="<a href='https://niftycoon.in/'>NifTyocon, a tag link</a>">
    <input type="hidden" name="bottom_msg[]" value="We'll get back to you shortly.">

    <!-- Regards can added or if you want to set regards as user name set value string:1 or msg:1 or if don't want to include regards please leave blank -->
    <input type="hidden" name="regards" value="<u>NifTycoon Team(u tag underline)</u>">

    <!-- File Upload Inputs -->
    <p><strong>Attach image(s):</strong></p>
    <input type="file" accept="image/*" accept="." name="img[]" multiple><br><br>

    <p><strong>Attach PDF(s):</strong></p>
    <input type="file" accept=".pdf" name="pdf[]" multiple><br><br>

    <p><strong>Attach document(s):</strong></p>
    <input type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.xls,.xlsx,.zip" name="docs[]" multiple><br><br>

    <!-- Files already stored on server (simulated DB files) -->
    <p><strong>Select existing server files:</strong></p>
    
    <!--<input type="text" name="db_file[]" value="../HEW FIRE DOOR BROCHURE.pdf"><br>-->
    <!--<input type="text" name="db_file[]" value="uploads/docs/specsheet.pdf"><br><br>-->
    
    <!-- These are the user alert message and header after sending mail successfully -->
    <input type="hidden" name="user_alert_message" value="Mail sent successfully, thank you we will contact you back">
    <input type="hidden" name="success_header" value="/index">
    
    <!--Google recaptcha user selection add before submit button-->
    <div class="g-recaptcha" data-sitekey="6LcfChErAAAAAFDzNU3Izk0MDupNiks8N61Pt7AE"></div>
    
    <button type="submit">Send Mail</button>

  </form>
  
  <!-- Google recaptcha script tag add below </form> tag-->
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>

</body>

</html>